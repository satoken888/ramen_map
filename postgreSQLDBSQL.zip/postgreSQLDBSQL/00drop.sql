DROP VIEW IF EXISTS public.add_datetostore;
DROP VIEW IF EXISTS public.datelist;
DROP VIEW IF EXISTS public.adddate;
DROP VIEW IF EXISTS public.datemake;
DROP TABLE IF EXISTS public.store;
DROP TABLE IF EXISTS public.storeinfo;
