UPDATE store
SET 定休曜日数字 = CASE WHEN 定休曜日 =  '日曜日' THEN 0
                        WHEN 定休曜日 =  '月曜日' THEN 1
                        WHEN 定休曜日 =  '火曜日' THEN 2
                        WHEN 定休曜日 =  '水曜日' THEN 3
                        WHEN 定休曜日 =  '木曜日' THEN 4
                        WHEN 定休曜日 =  '金曜日' THEN 5
                        WHEN 定休曜日 =  '土曜日' THEN 6
ELSE -1
END ;

INSERT INTO storeinfo ( "ID", 日付, "状況FLG" )
SELECT add_datetostore."ID",add_datetostore.generate_series, 1 
FROM add_datetostore;

UPDATE storeinfo SET 曜日数字 = date_part('dow', 日付);
UPDATE "storeinfo" SET "状況FLG" = 0 from store WHERE "store"."定休曜日数字" = "storeinfo"."曜日数字" AND "store"."ID" = "storeinfo"."ID";