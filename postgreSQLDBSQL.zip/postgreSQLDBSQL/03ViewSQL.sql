-- View: public.datemake

-- DROP VIEW public.datemake;

CREATE OR REPLACE VIEW public.datemake
 AS
 SELECT generate_series.generate_series
   FROM generate_series(now()::timestamp without time zone, date_trunc('MONTH'::text, now()::timestamp without time zone + '2 mons'::interval) + '00:00:00'::interval, '1 day'::interval) generate_series(generate_series);

ALTER TABLE public.datemake
    OWNER TO postgres;

-- View: public.adddate

-- DROP VIEW public.adddate;

CREATE OR REPLACE VIEW public.adddate
 AS
 SELECT datemake.generate_series::date AS generate_series
   FROM datemake;

ALTER TABLE public.adddate
    OWNER TO postgres;

-- View: public.datelist

-- DROP VIEW public.datelist;

CREATE OR REPLACE VIEW public.datelist
 AS
 SELECT adddate.generate_series,
    store."ID"
   FROM adddate,
    store
  ORDER BY adddate.generate_series, store."ID";

ALTER TABLE public.datelist
    OWNER TO postgres;

-- View: public.add_datetostore

-- DROP VIEW public.add_datetostore;

CREATE OR REPLACE VIEW public.add_datetostore
 AS
 SELECT datelist.generate_series,
    datelist."ID"
   FROM datelist
     LEFT JOIN storeinfo ON datelist.generate_series = storeinfo."日付" AND datelist."ID" = storeinfo."ID"
  WHERE storeinfo."ID" IS NULL;

ALTER TABLE public.add_datetostore
    OWNER TO postgres;
