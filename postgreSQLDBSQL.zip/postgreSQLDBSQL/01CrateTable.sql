-- Table: public.store

-- DROP TABLE IF EXISTS public.store;

CREATE TABLE IF NOT EXISTS public.store
(
    "ID" integer NOT NULL,
    "店名" text COLLATE pg_catalog."default",
    "住所" text COLLATE pg_catalog."default",
    "電話番号" text COLLATE pg_catalog."default",
    "定休曜日" text COLLATE pg_catalog."default",
    "定休曜日数字" integer,
    "営業時間" text COLLATE pg_catalog."default",
    "最終更新日" date,
    CONSTRAINT store_pkey PRIMARY KEY ("ID")
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.store
    OWNER to postgres;

-- Table: public.storeinfo

DROP TABLE IF EXISTS public.storeinfo;

CREATE TABLE IF NOT EXISTS public.storeinfo
(
    "ID" integer,
    "日付" date,
    "状況FLG" integer,
    "備考" text,
    "曜日数字" integer
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public.storeinfo
    OWNER to postgres;